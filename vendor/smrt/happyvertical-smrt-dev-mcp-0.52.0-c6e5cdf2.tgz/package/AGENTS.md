# @happyvertical/smrt-dev-mcp

Tier 2 MCP server for development — code generation, project introspection,
deterministic SMRT ecosystem knowledge, and portable agent workflows.

## Tools

| Tool | Purpose |
|------|---------|
| `generate-smrt-class` | Generates `@smrt()` class with fields, decorator config, imports |
| `introspect-project` | Scans project directory for SMRT objects; compact summary by default, `detail: 'full'` for field/schema/method detail |
| `review-smrt-project` | Advisory downstream ecosystem alignment review for dependencies, storage, app shell, auth/tenancy, and manifest generation |
| `reflect-knowledge` | Reports deterministic SMRT + HappyVertical SDK knowledge coverage and freshness |
| `reflect-domain-knowledge` | Reports downstream/domain artifact coverage and freshness |
| `check-knowledge-freshness` | Runs deterministic agent-doc and stale-reference checks |
| `build-context` | One context entry: `task: review` (file-anchored findings + `reviewHints` + prompt bundle) or `task: architecture` (ranked packages + recommendations); replaces the four `build-*-context` tools (#2780) |
| `smrt-review` | Deprecated name for `build-context` `task: review`; removed next minor |
| `build-package-specialist-context` | Builds deterministic package-specific Workbench context and source references |
| `smrt-architecture` | Deprecated name for `build-context` `task: architecture`; removed next minor |
| `list-agent-skills` | Lists bundled harness-agnostic agent skills |
| `get-agent-skill` | Returns a bundled agent skill as Markdown plus optional references |
| `migration-status` | Live migration status from the `_smrt_schema_migrations` system table — completed/running/failed/rolled_back counts, latest completed and failed migrations (runtime provenance; read-only; optional live DB, #1824) |
| `job-health` | Live job queue health from the `_smrt_jobs`/`_smrt_workers` system tables — counts by status, stuck/failed jobs, worker liveness; payloads/results never read (runtime provenance; read-only, #1824) |
| `schedule-health` | Live agent schedule health from the `_smrt_agent_schedules` system table — due/overdue/errored counts, last/next run; sensitive `agentConfig` never read (runtime provenance; read-only, #1824) |
| `dispatch-health` | Live dispatch health from the `_smrt_dispatch`/`_smrt_dispatch_subscriptions` system tables — stuck/pending by type/status, subscription topology; payloads/metadata never read (runtime provenance; read-only, #1824) |
| `recent-changes` | Tail of the `_smrt_changes` append-only change feed with cursor semantics, filterable by table and tenant (runtime provenance; read-only, #1824) |
| `registry-drift` | Registry drift report — `_smrt_registry` is retired and reported as such, never queried or fabricated (read-only, #1824) |
| `runtime-registry` | Sanitized snapshot of the booted `ObjectRegistry` from project + installed manifests; no project code executed (booted provenance; read-only, #1831) |
| `runtime-object` | One booted object's sanitized definition plus generated DDL (booted provenance; read-only, #1831) |
| `runtime-schema-diff` | Booted registry schemas vs live dev DB via the `db:diff` comparer; introspection only, no drops/relaxations (runtime provenance; read-only, #1831) |

`pnpm knowledge:check --strict --format markdown` compares this catalog and the
README parameter tables to the exported `TOOLS` definitions. Add or change a
tool schema and its authored documentation in the same commit.

## Knowledge Discovery (#2143)

Discovery reads the workspace globs instead of assuming `<root>/packages`:
`pnpm-workspace.yaml` `packages:` (literals, `dir/*`, `**`, `!` negations), then
`package.json#workspaces`, then a `packages/*` fallback. `findProjectRoot` looks
for a workspace declaration only — requiring a literal `packages/` directory is
what mis-rooted every `apps/*` product. The workspace root is indexed whenever it
has a `package.json`, which is how single-package repos resolve; it is scanned
with the member package directories excluded so it can own objects without
absorbing theirs.

Workspace globs are a filesystem trust boundary. Absolute paths and `..`
segments are rejected, and every matched directory is realpath-confined to the
workspace root before its manifest is read. All positive globs share a 10,000
directory-entry traversal budget; exceeding it is a fatal diagnostic that
returns no partially discovered package set. This cardinality limit preserves
valid deeply nested `**` workspaces without allowing repeated globstars to
amplify into unbounded filesystem work. Discovery also stops before package
reads when more than 512 packages match, revalidates confinement immediately
before reading each package, and runs at most eight scanner fallbacks at once.

### Consumer apps (#2275)

An app that installs the published packages authors none of them, so workspace
discovery alone sees nothing. Every installed `@happyvertical/smrt-*` package,
plus the known SDK packages, is resolved from the project's and each workspace
package's `node_modules/@happyvertical` scope directory and marked
`isInstalledDependency`. The filesystem enumeration and canonical doc reader are shared with CLI snapshots
through `smrt-scanner/knowledge`; enrichment stays here. This is an enumeration, not a walk: pnpm materializes
a store whose entries link back out to their siblings, so a descent reads the
same package once per path that reaches it. Real paths deduplicate the result;
each package is still read through its `node_modules` path, because a realpath
escapes the root wherever an ancestor is a symlink. A workspace package linked
into a sibling's `node_modules` is authored source and is never marked
installed.

- `--scope installed` reports exactly those packages. `local` and `package`
  exclude them; `project` includes them; the index also lists them separately
  as `installedPackages` (`schemaVersion: 3`). It is a reporting scope:
  `dev:knowledge-check` has no authored packages to gate under it.
- Each package carries `agentDocSha256`, the hash of its shipped `AGENTS.md`.
  That is the drift signal a consumer diffs against a recorded baseline — a
  version bump is not, because most releases do not touch a documented surface.
- The freshness gate skips installed packages entirely: indexed, never checked.
  A consumer cannot add an `AGENTS.md` to a dependency, and a published
  package's artifact hashes cannot match its republished sources.
- Coverage and the `no-smrt-objects-discovered` guard count authored packages
  only. Dependencies ship their own objects, so counting them would make that
  guard unreachable in exactly the projects most likely to have broken
  discovery. A project whose own packages contribute nothing while its
  dependencies do gets the `no-authored-smrt-objects` warning instead.

Per package, objects resolve in this order, and the winner is recorded in
`objectSource` with a reason:

1. `domain-artifact` — `.smrt/`, `dist/`, or `src/manifest/smrt-knowledge.json`
2. `manifest` — package-local manifest, after ownership validation
3. `scanner` — `OxcScanner` + `ManifestAdapter` over the package's sources
4. `none` — with a machine-readable reason

The index exposes `coverage` and `diagnostics` (added in `schemaVersion: 2`). Zero
discovered objects is an **error-grade** diagnostic that names the roots and
artifact paths checked plus the fix, and it propagates into
`build-context`/`reflect-*` results and prompt bundles.

A workspace-root package has an empty `relativeDirectory`, so package paths are
built with `packageRelativePath`/`packageDocPaths` rather than interpolation —
otherwise emitted docs read `/AGENTS.md` and changed-file matching compares
against a leading `/` and selects nothing. The root owns any changed path no
member package owns, mirroring the member-excluded scan.

## Agent Skills

Bundled skills live under `skills/`, the Agent Plugins fixed discovery
location. They are plain Markdown procedures
with YAML frontmatter (`name` and `description`) and harness-neutral body text.
Skill-aware harnesses can parse the frontmatter; other harnesses can ignore it.

- `skills/smrt-code-review/SKILL.md` — downstream SMRT code review workflow.
  Agents should fetch it with `get-agent-skill`, then call `build-context` (`task: review`) for
  deterministic context, inspect the actual diff, and produce a findings-first
  review.


## Project runtime prerequisite

The standalone MCP installation includes static tooling and the scanner, not
SMRT core, SQL drivers, AI, or filesystem providers. All 21 tools remain listed.
Code generation, knowledge/context tools, agent skills, and introspection of a
built manifest work without an installed runtime.

Source-scan enrichment (`introspect-project` without a built manifest) and the
runtime tools require `@happyvertical/smrt-core` installed in the selected
project. Install the project's dependencies first. The server resolves core's
public exports from that project and resolves SQL/config from the same core
installation using normal Node resolution, including hoisted workspace dependencies.
It never retries resolution from the MCP server module location. Use `directory`
for introspection, `projectPath` for runtime tools, or launch from the project
root. HTTP `--project` and the in-app host pin the project explicitly.

A server process loads one runtime project. A request for another project fails
with `runtime_project_mismatch`; start a separate server or restart it for that
project. Missing/incompatible runtime installations return an actionable,
sanitized `runtime_dependency_unavailable` diagnostic. Static tools remain usable.
No DB configuration still returns the existing static-only diagnostic. Runtime
module import executes installed framework code, never the project's app entry.
Source enrichment runs in an isolated process with captured logs, preserving
schema/tenant/inheritance detail without writing onto MCP stdout.

## Usage

```jsonc
// .mcp.json or Claude Desktop config
{ "mcpServers": { "smrt-dev-mcp": { "command": "npx", "args": ["-y", "@happyvertical/smrt-dev-mcp"] } } }
```

For global MCP client config, do not use `pnpm exec smrt-dev-mcp` unless the MCP
server is always launched from a repo that installs the package. Prefer an
absolute `node /path/to/node_modules/@happyvertical/smrt-dev-mcp/dist/index.js`
launcher or a small wrapper script with an absolute Node path.

## MCP Tier Context

- **Tier 1** (Runtime): auto-generated from `@smrt()` objects — live data operations
- **Tier 2** (Development): this package — code generation and project analysis
- **Tier 3** (Docs): framework documentation access; `smrt-docs-mcp` is no longer launched from this monorepo unless an external package/repo is installed and configured explicitly

## Key Files

- `src/index.ts` — MCP server setup, tool registration
- `src/knowledge/index.ts` — deterministic SMRT, SDK, and downstream domain knowledge discovery; workspace-glob expansion, provenance, coverage, and diagnostics
- `src/agent-skills.ts` — bundled skill registry and file loader
- `plugin.json` / `mcp.json` — Agent Plugins 1.0.0 portable root manifests
- `skills/smrt-code-review/SKILL.md` — downstream SMRT review procedure
- `src/tools/generate-smrt-class.ts` — class generation logic and package-ready templates
- `src/tools/introspect-project.ts` — manifest-first project scanning, falling back to `@happyvertical/smrt-scanner`
- `src/dev-plane.ts` — in-app runtime dev-plane (#2782): `createDevPlane({ token, projectRoot, db })` serves JSON + MCP on one mount with loopback/bearer guards and a positive catalog (`registry-live` + the nine runtime tools); mounted by the generated `_dev/[...tool]` SvelteKit route
- `src/runtime.ts` — `RUNTIME_TOOLS` map for in-process callers (`smrt dev:runtime` fallback)
- `src/tools/review-smrt-project.ts` — advisory ecosystem-alignment checks for downstream projects

## Gotchas

- **Read-only**: never writes files or executes generated code
- **Model-agnostic**: review and architecture tools return deterministic
  findings/context and prompt bundles; they do not call model providers
- **Domain artifacts first**: discovery must prefer `.smrt/smrt-knowledge.json`,
  then `dist/smrt-knowledge.json`, then source artifacts before raw manifest
  fallback
- **Structural projection stays additive and sanitized**: schema-version-1
  domain artifacts and raw-manifest fallback both carry tenant mode/field,
  `cti`/`sti`, conflict columns, method signatures, and selected field schema
  facts. Preserve `methods: string[]`; remove top-level and `_meta` sensitive
  fields before deriving both fields and relationships, and remove their field
  and snake-case column names from projected conflict columns.
  If a custom tenant field is sensitive, retain scope/mode but omit its name.
  A schema-v1 artifact without `sensitiveFieldsExcluded: true` is legacy: use
  the owning raw manifest to allowlist its current non-sensitive fields and
  structural identifiers, or omit uncorroborated field facts fail-closed.
- **Skill loading**: bundled skills must be included in `package.json` `files`
  because runtime reads them from the installed package directory
- **Portable plugin boundary**: `mcp.json` launches only `./dist/index.js` from
  the plugin root. Paths must remain contained after resolution. Clients, not
  the package, provide the reserved `PLUGIN_ROOT` and `PLUGIN_DATA` environment
  variables and manage OAuth or all other credentials; do not add secret-bearing
  environment variables or headers to portable config.
- **Working Draft compatibility**: Agent Plugins 1.0.0 remains a Working Draft.
  Keep `plugin.json` and `mcp.json` pinned to the canonical 1.0.0 schema IDs,
  validate against the packaged `schemas/agent-plugins-1.0.0/` snapshots
  offline, and do not add streamable HTTP until #2147 provides the endpoint.
- **Field type mapping**: `text`, `integer`, `decimal`, `boolean`, `datetime`, `json` — maps to SMRT field helpers (but prefer TypeScript defaults per framework convention)
- **Capture manifest-enrichment output**: `generateSchemas` and
  friends write progress lines to **stdout** through the SDK logger, which is the
  MCP server's JSON-RPC channel. Suppressing `console.log` is not enough. The
  source introspection therefore captures an isolated process’s output. The
  knowledge scanner fallback skips schema enrichment, so
  scanner-provenance packages carry no `columnType` and contribute 0 to the
  `uuidColumns` fact — `objectSource` makes that visible.
- **Aggregate manifests poison relationship facts**: a runtime
  `.smrt/manifest.json` frequently registers a package's dependencies too.
  Objects whose `packageName`/`qualifiedName` disagree with the owning package are
  rejected with a diagnostic. A *consuming* package's artifact can also
  re-qualify its dependency's objects under its own name, which prefixes cannot
  detect. `summarizeRelationshipsV2` therefore collapses a shared
  `className::tableName` **only across a dependency edge** (a package can only
  restate its own dependencies' objects) and reports
  `duplicate-object-identity`. Two unrelated packages that happen to share a
  class and table name — `Account::accounts` exists in both smrt-messages and
  smrt-ledgers — are distinct objects and both keep contributing.
  - Grouping is by **connected component**, not a greedy pairwise match: two
    independent consumers restating one shared dependency have no edge to each
    other, so a greedy pass would keep both and double-count.
  - The surviving copy is the one the others **depend on**, since ownership
    follows the dependency direction. Provenance is not a sufficient signal —
    preferring a `scanner` copy kept `smrt-support`'s compatibility subtype over
    the canonical `smrt-projects` model and changed the facts.
- **Budgets are enforced at the transport boundary**: `KnowledgePackage` carries
  the full `agentDoc` and domain manifest, so the MCP handlers project a compact
  package record for `summary` (default) and `full`. `full` embeds package docs,
  structural facts, and modules selected by changed paths, focus, or Modules-table
  source mappings (including globs); other module paths remain discoverable.
  `complete` preserves full package records and embeds every module. CLI context
  JSON uses the same projection; `--complete` opts into full export. Library
  builders retain full objects. Snapshot commands list module paths by default
  and accept `--complete` to embed bodies.
- **Private packages skip packaging checks**: the `files` allowlist governs npm
  publication, so `private: true` packages are exempt; authored docs are still
  required. A workspace root is exempt from both — but **only when member
  packages exist**. In a single-package repo the root is the published package,
  so exempting every root would make the freshness gate a no-op for exactly the
  layout #2143 added support for.
- **Nested workspace members own no canonical docs**: instruction chains are
  additive, so a package nested inside another workspace package (
  `packages/smrt-playground/host`) must not carry `AGENTS.md`/`CLAUDE.md` — an
  agent would load the parent's and its own. Those two checks are skipped for it
  and a `nested-agents-md` error fires if one reappears; the expertise belongs in
  the parent's linked `agents/<module>.md`.
- **The money/rate lint reads source, not the manifest** (#2361): a manifest
  records a column's type but not whether anyone chose it, so only the source
  distinguishes `@field({ type: 'decimal' })` (a decision) from `= 0.0` (a
  default nobody made). Severity is split by what the repo can satisfy today,
  not by preference: `numeric-precision-rate` is an `error` on
  `@happyvertical/smrt-*` (the framework has zero violations, so the gate holds
  at zero), while `numeric-precision-money` only `warn`s — 21 framework fields
  across commerce, projects, subscriptions, support and the conformance fixture
  still declare money decimal, and converting them means changing live column
  types (REAL→INTEGER is not a whitelisted upgrade) and rescaling stored values
  by 100. Consumer packages always warn. A cheap textual pre-filter keeps the
  check from parsing the whole workspace.
- **`maxChars` budgets the objects payload, not the whole response**: project
  metadata and diagnostics are always returned in full, because a diagnostic is
  how discovery reports that it found nothing (#2143). Budgeting it away would
  hide the failure the caller needs to see.
- **Coverage and diagnostics are computed before scope filtering**: they answer
  "did discovery work", which is a whole-workspace property. Deriving them from
  the scoped subset made `scope: 'sdk'` report a false discovery failure.

## Validation

Run package `test`, `typecheck`, and `build`, then
`pnpm --filter @happyvertical/smrt-dev-mcp verify:pack`. The packaging gate packs
MCP/scanner/types, installs only their production dependencies into a fresh
external npm consumer/cache, rejects a core/SQL/files/AI closure, and exercises
stdio initialization, all 21 tool declarations, static calls, and missing-runtime
setup. It requires registry access. Core knowledge compatibility tests cover the
scanner-owned discovery/graph algorithms through the existing core entrypoints.
