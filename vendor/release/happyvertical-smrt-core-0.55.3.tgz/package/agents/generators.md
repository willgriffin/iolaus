# smrt-core/code generators

Module semantics for `src/generators/` + `src/vite-plugin/`. Package orientation, the cross-module
invariants, and the traps that apply before editing anything live in
[../AGENTS.md](../AGENTS.md) — read that first.

## Code Generators

| Generator | Location | Output |
|-----------|----------|--------|
| REST API | `src/generators/rest.ts` | OpenAPI-compliant CRUD endpoints |
| MCP Server | `src/generators/mcp.ts` | Model Context Protocol tools |
| Web collections | `src/vite-plugin/web-collections.ts` (selectors) + `generateWebModule` | `@happyvertical/smrt-virt-web` — one typed collection definition per API-exposed REST collection (#1761), consumed by `@happyvertical/smrt-web` |

The same web virtual module exports `webMcpToolDefinitions` (#2518), a
canonical per-tool array selected independently of list materialization. Every
non-empty canonical API action set contributes tools, so get-only and
custom-action-only models are discoverable; custom actions declared on a
`SmrtCollection` merge into the owning row collection. Each definition carries
complete route and invalidation metadata. `collectionDefinitions` and its
embedded descriptor copy remain unchanged for existing cache-backed consumers.

Generated API clients share `selectApiClientEntries()` across the runtime Vite
module, its ambient declaration, and physical prebuild declarations. When a
collection class and its populated model share an endpoint, the model owns the
canonical collection key and row payload schema; the collection class remains
available under a deterministic class-derived secondary key. Selection and
collision suffixes must not depend on manifest insertion order (#2027).
Route emission iterates manifest objects in the same deterministic
qualified-identity order (`orderedManifestObjectEntries`), so when two models
share one collection the last writer of each route file — and therefore the
CRUD method set `resolveGeneratedEndpointCrudMethods` mirrors into
`smrt-client.d.ts` — is stable across scan orders (#2754).
For aggregated manifests, inheritance and item-type references resolve exact
qualified names first, then package-local simple names, then a stable identity
fallback so duplicate class names across packages cannot reintroduce ordering.

The web module also emits a build-time **`manifestHash`** constant (#1764): `computeWebManifestHash(manifest)` is a deterministic, replica-stable digest of the emitted web-collection SHAPE (name/className/endpoint/idField/actions/fields/relationships), canonicalized (recursive key sort) before `sha256 → base64url`, truncated to 16 chars — so the same schema always hashes the same, and a field add/remove/type-change/edge-change changes it. A change means old persisted client rows may mis-hydrate, so smrt-web keys its durable persistence namespace on it and its `updateAvailable` contract signal compares against it. Four co-managed emission sites must not drift: the runtime value (`generateWebModule`), the `@happyvertical/smrt-virt-web` ambient d.ts (`vite-plugin/index.ts`), the physical `@smrt/web` d.ts (`prebuild/index.ts`), and the hand-written type mirror in `@happyvertical/smrt-web` (`packages/smrt-web/src/index.ts` — dependency-free, so textual sync only).

`webMcpToolDefinitions` is deliberately outside that digest: tool-only route,
identifier, or annotation changes cannot alter persisted row hydration.

Per-field web emission (#2046): `buildWebFieldDefinitions` carries `description` (from `@field({ description })`) and sanitized `ui` hints (from `@field({ ui: { basic, group, order, locked } })`, read off the manifest `_meta.ui` bag through per-key type guards) into each emitted field definition, and `buildWebToolDescriptors` threads the same `description` into browser MCP tool schemas. `sensitive`/`transient` fields are excluded from emission entirely, so their descriptions never ship. Both keys are conditional, so hint-less schemas emit byte-identical definitions (and hashes) as before; adding a description/ui hint changes the manifest hash — deliberate over-invalidation, harmless per the #1764 contract.

## Generated MCP server output language

`MCPGenerator` builds every file as TypeScript, so the requested `outputPath`
extension decides what is written (#2279). `.ts`/`.mts` targets keep the source
verbatim for `tsx` or Node type stripping — which is why the generated source
must stay erasable-syntax-only (no parameter properties, enums, or namespaces).
Every other target (`.smrt/mcp-server/index.js` by default) is transpiled to
JavaScript with lazily loaded `oxc-transform` before writing, because the
printed run script and the generated `claude-config.example.json` both invoke
it with plain `node`. Ordinary core imports and `.ts`/`.mts` output therefore
do not load OXC's native bindings.
This keeps `typescript` dev-only in `@happyvertical/smrt-core`; generated MCP
source must remain erasable-syntax-only. A `.cjs`/`.cts` target is rejected
outright: generated servers are ES modules. `src/generators/mcp-emit.ts` owns
those decisions — do not reintroduce a bare `writeFile` of generated source.

Modular output writes `config`, `tools/index`, and `handlers/index` with the
entry point's own extension, and emits the entry's relative import specifiers
with that same extension, so the files it imports both exist and load with the
same module semantics — an `.mjs` entry gets `.mjs` siblings, not `.js` ones a
CommonJS package would then parse as CommonJS. The entry is written at the
requested path rather than a hardcoded `index.js`.
Generated code also has to be valid in an ES module: `arguments` is not a legal
binding name there, however convenient it reads.

## Browser-plane playbook preflight route (#2590)

`GET {basePath}/_preflight?key=<playbook key>` (`src/generators/preflight-route.ts`)
is an advisory, read-effect, idempotent report of what a caller's playbook would
be allowed to do — capability *selection*, never authorization. Resolution and
verdict shaping live in `@happyvertical/smrt-playbooks`, which depends on this
package, so core takes the evaluator as the `APIConfig.playbookPreflight` seam and
the dependency stays one-way. Without a provider the route 404s.

**`authMiddleware` is never invoked by preflight**, and that is enforced
structurally rather than by discipline: `PlaybookPreflightRouteOptions` has no
auth member of any kind, and `rest.ts` passes the boolean `appAuthConfigured`
instead — so there is no handle in the module to invoke by mistake. A synthetic-
`Request` dry run is explicitly not an option: the middleware is request-bound,
returns a `Response` rather than a boolean, and may consult session stores,
rate-limit, or audit. The app-auth layer therefore reports `unknown`, which is the
honest answer, and a future `authPredicate` seam can fill it in without changing
the contract.

The static layers preflight predicts against are exported from the same module —
`isApiActionEnabledForObject`, `isRestActionRoutable`, `isRestRoutePublic`,
`restFieldReadPermissions`, `restMethodForApiAction`,
`resolveRegisteredObjectName` — and `APIGenerator`'s own
`isApiActionEnabled` / `isRoutePublic` now delegate to them, so the route and the
prediction of the route cannot drift. Exposure and existence are separate
questions: `include`/`exclude` gate a route, they do not conjure one, so
`isRestActionRoutable` additionally requires a custom action to be declared in
`api.routes` — the only map `dispatchCustomCollectionAction` iterates. A custom
action is predicted against the verb its own route config declares, so a
`public: 'read'` opt-out neither silently covers a `POST` action nor falsely
denies a declared `GET` one. Every unresolvable key returns the provider's single uniform
"unavailable" body with an unconditional 200: unknown and unauthorized keys are
indistinguishable at the HTTP layer too.

## Emitted agent surface (#2591)

Generated model tools have always been build-time artifacts — virtual module,
manifest, knowledge graph. View intents (#2588) and playbooks (#2589) existed
only once something mounted, so "what can an agent do in this app" had no answer
short of enumerating every route. This closes that.

The same OXC scan that builds the manifest also runs the scanner's
agent-surface matcher (`ScanResults.agentSurface`). `smrtPlugin()` captures it
in `scanWithOxc`, projects it with `toKnowledgeAgentSurface`, and passes it to
`buildDomainKnowledgeManifest` as `agentSurface`. Note that declaration
discovery is NOT bound to the plugin's `include` glob — an app that scans
`src/lib/objects/**` for models still has its `src/lib/agent/*.intents.ts`
sidecars found (see `packages/scanner/AGENTS.md`). Two more consequences worth
holding onto:

- **It never touches `manifest.json`.** The runtime manifest stays
  runtime-focused; the agent-addressable surface is an agent/developer contract,
  so it lands in `.smrt/smrt-knowledge.json` and `dist/smrt-knowledge.json`
  only, under `agentSurface: { intents, playbooks, diagnostics }`.
- **It is passed in, not scanned in `knowledge.ts`.** The scanner carries a
  native parser binary and `smrt-core`'s main entry is browser-reachable, so
  core's sync knowledge builder must not import it. The Vite plugin already
  imports the scanner lazily on the Node side and is the only caller that writes
  this artifact.

The field is **omitted entirely** when a package declares nothing, which is what
makes it additive in practice rather than only on paper: every existing
package's checked-in artifact stays byte-identical.

Each declaring module gets a `sourceHashes` entry under the
`agentSurface:<package-relative path>` prefix (`AGENT_SURFACE_HASH_PREFIX`), so
EDITING an intent sidecar marks the artifact stale exactly like editing
`AGENTS.md` does (`stale-domain-knowledge`).

Hashes alone cannot see an **added** declaration, though: a brand-new sidecar
has no recorded hash to mismatch, the runtime manifest never carries intents,
and `AGENTS.md` is untouched — so every other signal stays green while the
artifact omits a real operation. `dev:knowledge-check` therefore also re-derives
the declaration SET from source and compares it to the artifact by identity,
reporting either direction as `stale-agent-surface`. The scan is bounded like
the numeric-precision lint: `src` only, behind the scanner's token pre-filter.

That re-derivation must model what the EMITTER sees, not merely what is on
disk, or it reports drift no rebuild can clear. Which files count is decided by
the scanner's exported `isAgentSurfaceSourcePath` — the same predicate the
emitter itself uses, never a list copied into the checker — and the per-file
results run through `mergeAgentSurfaces` before comparing, because the merge is
where a duplicate identity and a derived tool-name collision are resolved and
the artifact is the merged result.
Diagnostics are compared alongside identities: a sidecar containing only a
computed declaration adds no identity and has no prior hash, so without that,
"a diagnostic, never silence" would quietly become "a diagnostic, until the
artifact goes stale". The walk covers `<pkg>/src` while the emitter globs the
whole project root, so an emitted entry from outside `src` is not reported as
missing — this check did not look there, and claiming otherwise would be an
error nothing could clear.

Both `stale-*` codes are warnings by default and errors under `--strict`, which
is what CI runs. Alongside them: `agent-surface-missing-identity`,
`agent-surface-duplicate-identity`, and `agent-surface-empty-playbook` are
errors, and `agent-surface-not-static` and `agent-surface-tool-name-collision`
are warnings. A cross-file duplicate arrives as a *diagnostic* rather than two
entries — the scanner's merge already dropped the loser — so that diagnostic
maps to the duplicate error rather than the not-static warning; otherwise the
error would be unreachable for the case it exists to catch.

A `tool-name-collision` diagnostic (#2725) is derived from the MANIFEST, not
from the declaration: the plugin compares each emitted intent against
`buildWebMcpToolDefinitions` for the same build, which is already filtered by
the exposure policy, and appends the result to the surface. So it is excluded
from the drift comparison above — that pass re-derives declarations from source
alone and has no manifest, so counting one as "declared" would report every
collision as drift no rebuild could clear. The check is advisory and drops
nothing: `defineIntent` accepts the id, so the intent is emitted, and the
document-global tool-name lock (#2613) rejects whichever registers second — the
build-time notice is the earlier, cheaper form of the same answer. A build
cannot see the provider's WebMCP `namespace` or `effects` policy, either of
which separates the pair outright, so the message states that precondition
rather than asserting the collision.

`smrt doctor` prints the whole surface — model tools, intents, playbooks — from
these artifacts alone, with no application running.

## Custom-action contract

`resolveCustomActionMetadata()` is the common discovery and invocation contract
for generated REST routes and API clients, MCP, CLI, WebMCP, and simple
REST-resource discovery. Receiver scope comes from the executable method, never a
configuration-only `api.routes[name].scope` override: instance model methods
are item-scoped and require `id`; static model methods and recognized
`SmrtCollection` methods are collection-scoped and do not accept `id`. Route
configuration may still choose its path and HTTP verb, but it cannot turn an
instance call into `ClassRef.action` or vice versa.

When scanner method metadata exists, discovery projects each named parameter
and its JSON-schema type, and invokers pass the values positionally in declared
order. The legacy single `options` bag remains compatible when metadata is
absent (or the declared method takes `options`). Do not infer this from runtime
function arity. An omitted typed `options` parameter remains `undefined`, so a
method's JavaScript default initializer continues to apply; an explicit `null`
remains `null`. Flat tool and CLI inputs reserve `id` for receiver parsing. If
an action declares an `id` parameter, its flat MCP/WebMCP field is `actionId`
(and CLI uses `--action-id`); REST keeps its independent path/body
namespaces. Typed CLI actions may use standard flag names such as `limit`,
`offset`, `where`, and `format` without those values being stripped as CRUD
flags.

Custom actions may return an explicit, domain-neutral failure object with
`ok: false`, `code`, and `message` plus optional `status`, `details`,
`retryable`, and `correlationId`. `normalizeCustomActionFailure()` redacts it;
generated REST returns `{ error: failure }` with the non-2xx status, while MCP
returns `isError: true` and `_meta['io.happyvertical/smrt']`. Opaque successful
objects (including `{ code, message }`) remain untouched; thrown exceptions are
not reclassified as domain failures.

Custom route metadata also classifies browser-tool effects. Set `effect` to
`read`, `write`, or `destructive`, with truthful `idempotent` and `openWorld`
flags. CRUD classification is fixed: list/get are read, create/update are write,
and delete is destructive. An undeclared custom action deliberately defaults to
destructive, non-idempotent, and open-world so a browser capability policy never
fails open.

Generated reads (`list`/`get`) on the REST and SvelteKit generators support conditional GET (helpers in `src/generators/conditional-get.ts`). ETag v2 (#1765): the validator is the table's change-feed version (`getTableVersion`) keyed by the request representation, so a **concrete** `If-None-Match` short-circuits into a 304 with an empty body **before** the collection query runs — an unchanged table revalidates with zero table scan. A wildcard `If-None-Match: *` is deferred until the payload builds (existence confirmed), so a missing item still returns 404, not a false 304. Tenant-scoped reads fold the active tenant into the representation (`resolveTenantEtagDiscriminator`) so one tenant's cached validator never satisfies another's read of the same URL. Routes whose GET renders via a **custom serializer** (which can load related tables the base-table version can't observe) keep the v1 body-hash ETag (`#1757`, query-first but correct); the default `toPublicJSON` path — all REST reads and non-serializer SvelteKit reads — uses v2. v2 is weakly consistent by design (the cost of not reading the data): a revalidation in the sub-statement window between a committed write and its feed append can return a stale 304 that self-heals on the next revalidation. The other v2 window — a deploy that changes the response shape WITHOUT a table write — is closed by the **#1764 ETag salt**: `computeTableVersionEtag(version, representation, manifestHash?)` folds the build's web-collection shape digest into the digest, so a shape-only redeploy busts every read validator (`undefined` reproduces the pre-#1764 unsalted value byte-for-byte for direct helper callers). The generated SvelteKit route bakes the digest in as a `MANIFEST_HASH` constant (via `generateConditionalGetRouteHelper`'s `manifestHash` option, sourced from `computeWebManifestHash(manifest)`) — automatic for the SvelteKit transport. The runtime `APIGenerator` auto-populates the same salt from the runtime registry with `computeRuntimeWebManifestHash()` when `APIConfig.manifestHash` is omitted; explicit `APIConfig.manifestHash` still wins for custom setups. The digest scope is get-OR-list (`selectWebEtagSaltEntries`), so **get-only** routes are salted too. Strong consistency still requires the v1 body-hash path. Cache-Control policy (unchanged from #1757): `private, no-cache` by default; public models may opt into shared caching via `@smrt({ api: { public: true | 'read', cache: { sMaxage } } })` → `public, max-age=0, s-maxage=<n>`; non-public models never emit shared-cache headers. Tenant-scoped models (any mode) never emit them either — bodies vary with session-cookie tenant context that URL-keyed shared caches cannot see; `sMaxage` is neutralized to `private, no-cache` with a one-time warning.

## Generated dev-plane route (#2782)

`src/vite-plugin/dev-plane-route.ts` emits `<routesDir>/_dev/[...tool]/+server.ts`
only when `svelteKit.devPlaneRoute.enabled === true` and
`@happyvertical/smrt-dev-mcp/dev-plane` resolves from the consumer (same
resolvability guard as `_resources`). The route is dev-only (`$app/environment`
`dev`, else 404), refuses to start without `SMRT_DEV_MCP_TOKEN` (503), and
delegates everything else to `createDevPlane`, passing `getSmrtConfig(...).db`
from the embedded access prelude (below) so the plane shares the app's
connection.
Core never imports smrt-dev-mcp; only the generated file does, at consumer
runtime. The route carries the auto-generated header so the sweep owns it.

Generated SvelteKit write routes (#2977) call `requireRoutePermission(locals, action)` after `requireRouteAuth`: CRUD writes need `<collection>.create|update|delete` and mutating custom actions `<collection>.<method>` in the session permission snapshot on `locals`, else 403 (fail-closed; `api.public: true` stays open, `tenantContext.superAdminBypass` skips). See `packages/users/agents/permissions.md`.

## MCP protocol identifiers (#3219)

MCP discovery preserves existing names matching `[A-Za-z0-9_.-]{1,64}`.
Previously invalid names use their first 31 sanitized ASCII characters, `_`,
and the first 32 hex characters of SHA-256 over the JSON tuple
`[original class name, lowercased action name, original raw tool name]`.
This makes long or punctuation-bearing identifiers deterministic without
collapsing common prefixes. Discovery reserves compliant names first and fails
closed on any duplicate raw name or final alias collision instead of advertising
ambiguous dispatch (including class names differing only by case across packages).
Consumers must use the advertised name rather than constructing one.

The generator retains a separate class/action binding for each descriptor and
emits that mapping for generated runtimes. Dispatch, task eligibility, tenant
scoping, ordering, and STI metadata use this binding; protocol aliases are not
execution identities. The advertised catalog still gates execution. The direct
runtime-template API accepts `toolTargets`; omitting it retains the legacy
`object_action` convention for existing direct callers. Supply explicit targets
for canonicalized names or class names containing underscores. This contract
does not change CLI, REST, or WebMCP identifiers.

`MCPGenerator.getToolIdentity(tool)` exposes the generator-validated original
class, action, and raw generated name to in-process catalog composers. App MCP
uses it for class allow-lists, tenant checks, and compatible workflow guards;
those consumers must not reverse protocol aliases. The alias remains the sole
wire tool name and is still the key for public patterns and generic tool policy.

`MCPConfig.classNames` scopes generation (simple names, case-insensitive, or
qualified `@scope/pkg:Class`); omitted, every registered class is a candidate.
A simple name matching more than one registered class throws (scope it by
qualified name). Each tool keeps its class's registry key, and configuration,
fields, methods, dispatch, tasks and collections resolve through that key —
never through the first same-named class. Generated servers (single-file and
modular) carry it as `registryKey` in their tool targets and task actions and
use it for every emitted collection, policy, class and STI-base lookup;
`objectName` stays the wire/display name.
A host with an allow-list passes it so the duplicate-name check runs over the
published set only: an unrelated collision among classes it never lists must
not fail its catalog or calls (#3490). App MCP always scopes its generators.

## Generated route collection access (#3416)

There is no generated route-access module. Every generated SvelteKit route
that needs collections (CRUD, custom actions, `_changes`, `_events`,
`sync/apply`, `_dev`) embeds the prelude from
`generateCollectionAccessImports()` (`sveltekit-config-import.ts`): it imports
the generated `smrt-register` module, then the app's config module
(`$lib/server/smrt` by default) as `* as smrtApplication`, and destructures
`getCollection`/`getSmrtConfig` from `createGeneratedCollectionAccess()`
(`src/generated-collection-access.ts`). Generation fails before writing
anything when `configFileName` resolves to the registration module
(`smrt-register` with any script extension or case).
That helper resolves per call, never caching: a legacy `getCollection` /
`getSmrtConfig` export wins (deprecated, warned once per module, for one
release), else the exported app-runtime `runtime.getCollection()` /
`classOptions()`, else it fails with an error naming the module. `_resources`
and static collection-scoped actions only need registration, so they import
`smrt-register` and then the config module. When the config module is missing
and `@happyvertical/smrt-app-runtime/sveltekit` resolves from the consumer, the
generator writes a runtime-shaped default instead of the legacy
`getCollection` file.

## Enum-constrained fields (#3598)

The scanner emits `enum: [...]` on a manifest field typed as a TS enum or
string/number literal union. Registry-sourced fields mirror it into
`_meta.enum` (`createFieldFromManifest` / `mergeManifestField`); read it with
`readFieldEnum()` (top level first, then `_meta`), never directly. Generated
tool schemas (`fieldTypeToJsonSchema`, so MCP and WebMCP descriptors), OpenAPI
(`swagger.ts`) and the legacy `generateSchemaProperties` emit JSON Schema
`enum` for `text`/`integer`/`decimal` fields only; a nullable field appends
`null` to the list so `type: [.., 'null']` still validates. The client web
collection `fields` map does not carry `enum` yet (it feeds the shape digest and
three hand-mirrored d.ts files); tool inputs read it from the manifest field.
