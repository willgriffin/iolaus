# @happyvertical/smrt-tenancy

Multi-tenancy via AsyncLocalStorage context propagation with automatic query filtering and tenant ID population.

## Context Propagation

```typescript
import { withTenant, getTenantId, withSystemContext } from '@happyvertical/smrt-tenancy';

await withTenant({ tenantId: 'tenant-123' }, async () => {
  // All SmrtCollection queries auto-filtered by tenantId
  // All creates auto-populate tenantId
  const docs = await collection.list({}); // WHERE tenant_id = 'tenant-123'
});

await withSystemContext(async () => { /* bypasses all tenant checks */ });
```

**Critical distinction**: `withSystemContext()` sets a SYSTEM_CONTEXT_MARKER sentinel — different from "no context" (undefined). Interceptor can distinguish intentional bypass from missing context.

**Duplication-safe storage**: the underlying `AsyncLocalStorage` is a `Symbol.for`-keyed singleton on `globalThis`, so context survives Vite/vitest/SvelteKit pipelines that evaluate the module more than once — context entered through one module instance is visible to guards in another (#2077).

## Billing relationships (#3058)

`src/billing-relationship.ts` owns a separate reseller parent graph. It never
updates `smrt-users` `Tenant.parentTenantId` or tenant-scoped records. One row
per child stores the reseller and `self`/`reseller` owner mode; owner queries
derive one tenant ID. Mutations go through `BillingRelationshipService`, which
serializes graph writes and rejects cycles. The host supplies tenant existence
and optional authorization; no generated write surface is exposed. The model
stays a root export because generated consumer registration imports every
public non-collection manifest object from the root; withholding it breaks
every dependent's `register.js` (publish dry run, smrt#3074). The collection
stays unexported, as in smrt-chat. See the README for setup, access rules, and
migration guidance.

## Interceptor System

Hooks into SmrtCollection via `GlobalInterceptors.register()` (priority 100, runs first):

| Hook | Behavior |
|------|----------|
| `beforeList` | Injects `tenantId` into WHERE clause; validates existing filters match context |
| `beforeGet` | Same — resolves string lookups via core's `resolveGetStringFilter()` (UUID → `{ id }`, else `{ slug, context: '' }`) and adds the tenant predicate (#2365) |
| `beforeSave` | Auto-populates tenantId if empty + `autoPopulate: true`; validates if already set |
| `beforeDelete` | Validates instance.tenantId matches context |
| `beforeQuery` | Enforces raw SQL policy on tenant-scoped classes (`throw`/`warn`/`allow`) |
| `afterSave` | Emits `directory.<class>.created`/`updated` via `dispatchBus` for configured `directoryClasses` |
| `afterDelete` | Emits `directory.<class>.deleted` via `dispatchBus` for configured `directoryClasses` |

Mismatches throw `TenantIsolationError`. Missing required context throws `TenantContextError`.

**Optional-mode reads with no context pass through UNFILTERED at the interceptor.** That is intentional for trusted/admin call paths, but it means the interceptor alone does not protect a tenant-scoped model exposed as `@smrt({ api: { public } })`: an anonymous HTTP read has no context, so the interceptor would return every tenant's rows. The generated REST + SvelteKit read routes close this by injecting a `{ tenantId: null }` filter when tenancy is enabled but no context is active, so public/anonymous reads fail closed to **global (NULL-tenant) rows only** — mirroring the dispatch resolver's *enforced, no active tenant → global rows only* rule (#1782). Authenticated reads still scope to the caller's tenant via the interceptor.

## Read-Path Coverage (#2365)

Tenant scoping is a whole-path property — every read path is interceptor-aware,
not only collection list/get:

- **Get-by-slug**: `collection.get('<slug>')` works under a tenant context. The
  interceptor resolves string filters with core's `resolveGetStringFilter()`
  instead of assuming they are ids. Any custom `beforeGet` interceptor that
  rewrites a string filter must do the same.
- **Hydration and identity**: `new Model({ id | slug }).initialize()`,
  `loadFromId()`, `loadFromSlug()`, `getSavedId()` and `getId()` run their
  filters through the `beforeGet` pipeline, so constructor hydration cannot
  read another tenant's row and `getId()` can never adopt another tenant's
  same-slug row id (which would steer a later `save()` onto the foreign row).
  Required-mode classes fail closed (`TenantContextError`) when hydrated
  outside a tenant context; `withSystemContext()` / super-admin bypass remain
  the explicit cross-tenant paths.
- **Vector search**: `semanticSearch()` / `findSimilarToEmbedding()` restrict
  candidates to the tenant's rows BEFORE top-K ranking (the tenant predicate is
  resolved through the `beforeList` pipeline), so results are never starved by
  — and similarity ranks never leak — other tenants' content.
- **Collection memory**: `remember()`/`recall()`/`recallAll()`/`forget()` on a
  tenant-scoped collection key `_smrt_contexts.owner_id` per tenant
  (`__collection__:<tenantId>`) under an active tenant context. Isolation is
  strict: tenant-keyed memory never falls back to the shared `__collection__`
  key, and memory learned outside a tenant context is invisible inside one.
  Two edge semantics to know: under `withSuperAdminBypass()` reads skip
  filtering but memory still keys to the active tenant (scoped tighter, not a
  leak), and an empty-string tenant id resolves to the shared key (an
  empty-string tenant is a misconfiguration — real tenant ids are uuids).

## Registration — Two Patterns

```typescript
// Pattern 1: Tenancy decorator
@TenantScoped({ mode: 'optional' })
class Doc extends SmrtObject { @tenantId({ nullable: true }) tenantId: string | null = null; }

// Pattern 2: Core decorator (tenancy package reads this too)
@smrt({ tenantScoped: { mode: 'optional' } })
class Doc extends SmrtObject { tenantId: string | null = null; }
```

The exported `registerTenantScopedClass()` also accepts a simple or qualified
string selector for third-party classes and test doubles. A simple selector is
bound to the one exact core constructor when that name is uniquely resolvable;
it may be registered before core. Once bound, a later same-name package peer
does not inherit its policy. If two core classes exist before the simple
selector can bind, operations fail closed until the caller registers an exact
qualified name (for example, `@package/name:Doc`). No lookup strips a namespace
to guess an owner. If core clears a bound constructor and reuses its qualified
name, unregister and register the selector again; it will not silently transfer
policy to the replacement constructor.

Modes: `'required'` (default — throws without context) or `'optional'` (passes through if no context).

## Adapters

- **Express**: `createExpressMiddleware()` — uses `enterTenantContext()` (not withTenant, because middleware returns before handlers run)
- **SvelteKit**: `createSvelteKitHandle()` — stores context in `event.locals`
- **CLI**: `createCliContext()` — `run()`, `runWithTenant()`, `runAsSystem()`, `runAsSuperAdmin()`

## Super Admin Bypass

`withSuperAdminBypass()` keeps tenant context but disables auto-filtering. Different from `withSystemContext()` which removes context entirely.

## Gotchas

- **Context lost in callbacks**: `setTimeout(() => getTenantId(), 100)` → undefined. Fix: `TenantContext.bind(fn)`
- **Nested contexts override**: inner `withTenant()` overrides outer; restores on exit
- **Auto-populate only if empty**: if tenantId already set, interceptor validates (not overwrites)
- **Isolation checked at query time**: `list({ where: { tenantId: 'other' } })` throws immediately
- **Testing**: `resetTenancy()` + `setupTestTenancy()` in beforeEach; `testTenantIsolation()` helper
- **Natural keys are per tenant (smrt#2360)**: a tenant-scoped class with no explicit `conflictColumns` upserts on, and indexes, `(tenant_id, slug, context[, _meta_type])` — `save()` from tenant B with tenant A's slug is a second row, never an overwrite; within a tenant the natural key still dedups; NULL-tenant (`optional` mode, no context) rows dedup among themselves through the SDK's null-aware upsert but not through the index (NULLs are distinct), so raw SQL `ON CONFLICT (slug, context…)` on such a table no longer binds — use `WHERE NOT EXISTS`, and on PostgreSQL an advisory lock, as `ProfileTypeCollection.getOrCreateGlobalBySlug()` does. Core resolves tenant schema policy in order: explicit `@smrt`, manifest (including an omitted `tenantScoped`), exact-constructor `@TenantScoped()` reconciliation, then marked-field fallback; it never reads the standalone tenancy registry. This keeps schema and upsert behavior aligned before `enableTenancy()` runs. Rollout: deploy the code and `smrt db:migrate` together (neither version's create works against the other's index), and backfill `tenant_id` on legacy NULL-tenant rows first — a tenant-context save no longer adopts a `(NULL, slug)` row, it inserts beside it and that tenant stops seeing the legacy one (details in `packages/core/agents/schema-paths.md`).
- **Runtime-only registration is audited, and ownership keys follow the field**: a class registered with `registerTenantScopedClass()` whose manifest declares no tenancy still gets the tenant-led default key when it has a `tenantId` field (core infers OWNERSHIP from the field, never the read policy). `auditTenantScopedRegistrations()` reports per selector: `missing_tenant_field` (error — neither the model nor a registered ancestor declares the field; an STI child registered before its manifest loads inherits it from the parent, #3623), `natural_key_not_tenant_scoped` (warning — an explicit key omits the tenant column, so a second tenant's same-key save is refused with `TENANT_ISOLATION_VIOLATION`), `undeclared_tenant_scope` (info). Registration (or first use, when it precedes core) logs the error/warning findings once. Core's save guard, not the interceptor, is what stops a tenant-filtered lookup from upserting onto another tenant's row (see core `agents/schema-paths.md`).
- **Manifest/runtime mismatch fails closed (smrt#2763)**: if a cached manifest omits or sets `tenantScoped: false` while the exact runtime constructor carries `@TenantScoped()`, registration is rejected; regenerate the manifest. A rejected late manifest or conflicting promotion preserves a previously valid scoped registration. Applying `@TenantScoped()` to an already-global manifest registration that omits or disables tenancy instead marks that class unavailable to conflict-key, schema, and tenancy interceptor operations until a corrected manifest explicitly declares tenancy. This prevents a global unique key from conflicting with tenant-enforced reads or writes.

## Known exceptions to monorepo standards

- **`serializeInstance()` in `src/interceptor.ts` calls `instance.toJSON()` directly** (standards.md §7 forbids this in favor of `transformJSON()`). The interceptor must serialize arbitrary instances handed to it — including workspace stubs and plain-object test doubles whose classes may not extend `SmrtObject` and therefore have no `transformJSON()` hook. The call is duck-typed and falls back to manual key iteration when `toJSON` is absent. See the inline comment at the call site for the full rationale.
