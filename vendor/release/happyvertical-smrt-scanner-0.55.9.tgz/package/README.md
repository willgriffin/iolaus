# @happyvertical/smrt-scanner

High-performance TypeScript AST scanner using [OXC](https://oxc-project.github.io/) for s-m-r-t manifest generation. Extracts class, field, method, and decorator metadata from source files without executing them.

## Installation

```bash
pnpm add @happyvertical/smrt-scanner
```

## Usage

```typescript
import { OxcScanner, InheritanceResolver, ManifestAdapter } from '@happyvertical/smrt-scanner';
import { parseFile, parseSource, extractSmrtImports } from '@happyvertical/smrt-scanner';

// Scan a single file
const result = parseFile('/path/to/Product.ts');
// result.classes → RawClassDefinition[]
// result.smrtImports → Map of SMRT package imports

// Scan from source string
const source = `
  @smrt({ api: true })
  class Product extends SmrtObject {
    name: string = '';
    price: number = 0.0;
  }
`;
const parsed = parseSource(source, 'Product.ts');

// Full scanner with glob support
const scanner = new OxcScanner({ include: ['src/**/*.ts'] });
const results = await scanner.scan();

// Resolve inheritance across files
const resolver = new InheritanceResolver();
resolver.addClasses(results.classes);
const resolved = resolver.resolveAll();

// Convert to SMRT manifest format
const adapter = new ManifestAdapter();
const manifest = adapter.toManifest(resolved);
```

### CLI

```bash
# Scan and output manifest
smrt-scan src/**/*.ts
```

## API

### Classes

| Export | Description |
|--------|------------|
| `OxcScanner` | Scans TypeScript files for `@smrt()` decorated classes |
| `InheritanceResolver` | Resolves class inheritance chains across files |
| `ManifestAdapter` | Converts raw scan results to s-m-r-t manifest format |

### Functions

| Export | Description |
|--------|------------|
| `parseFile` | Parse a single TypeScript file and extract metadata |
| `parseSource` | Parse a TypeScript source string |
| `extractSmrtImports` | Extract s-m-r-t-related imports from a file |

### Key Types

`RawClassDefinition`, `RawFieldDefinition`, `RawMethodDefinition`, `RawDecoratorConfig`, `ResolvedClassDefinition`, `ScanResults`, `FileScanResult`, `OxcScannerOptions`, `InferredFieldType`, `FieldTypeInference`

## Dependencies

- Peer (optional): `@happyvertical/smrt-core`
