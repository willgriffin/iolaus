# @happyvertical/smrt-core

Foundation ORM, registry, schema/code generation, AI integration, and DispatchBus.
Read the module for the subsystem being edited; root AGENTS covers shared model
and repository rules.

## Modules

| Source | Scope | Module doc |
|---|---|---|
| `src/object.ts`, `src/collection.ts`, `src/child-accessors.ts` | Lifecycle, hydration, operators, STI, child accessors, dispatch | [agents/object-runtime.md](agents/object-runtime.md) |
| `src/revision-guard.ts`, `src/unchanged-indexed.ts`, `src/native-duckdb.ts` | Guarded writes, PostgreSQL revision precision, unchanged indexed columns on referenced DuckDB rows (#3737) | [agents/revision-guard.md](agents/revision-guard.md) |
| `src/collection.ts` | Projections, latest-related, facets, counts, read plans | [agents/collection-reads.md](agents/collection-reads.md) |
| `src/collection.ts` | Limits, sort whitelist, generated list order | [agents/query-bounds.md](agents/query-bounds.md) |
| `src/data-query.ts` | Transport-neutral bounded query normalization | [agents/data-query.md](agents/data-query.md) |
| `src/schema/`, `src/migrations/`, `src/cascade.ts`, `src/system/` | DDL parity, indexes, migrations, delete integrity, retention | [agents/schema-paths.md](agents/schema-paths.md) |
| `src/postgres-permissions.ts` | Explicit PostgreSQL ACL plans and atomic reconciliation | [deployment permission contract](../../docs/content/postgres-permissions.md) |
| `src/change-feed.ts` | Durable changes, cursors, table versions, retention | [agents/change-feed.md](agents/change-feed.md) |
| `src/change-feed-authz.ts` | Consumer table/row change-feed authorization hooks (#3020) | [agents/change-feed.md](agents/change-feed.md) |
| `src/change-signals.ts` | Signal bus, replica fan-out, SSE | [agents/change-signals.md](agents/change-signals.md) |
| `src/generators/`, `src/vite-plugin/web-collections.ts` | REST/CLI/MCP generation, manifest hashes, ETags | [agents/generators.md](agents/generators.md) |
| `src/vite-plugin/`, `src/consumer-plugin/`, `src/knowledge.ts` | Decorator UI hints, knowledge projection, generation snapshots | [agents/build-knowledge.md](agents/build-knowledge.md) |
| `src/knowledge-graph.ts` | Cross-package knowledge graph merge and freshness check (#2863) — see [standards](../../docs/content/standards.md) | — |
| `src/object.ts`, `src/collection.ts`, `src/learning/memory.ts` | Context memory and semantic search | [agents/memory.md](agents/memory.md) |
| `src/system/diagnostics.ts` | SELECT-only `_smrt_*` diagnostics reader behind smrt-dev-mcp runtime tools (#1824) | [agents/system-diagnostics.md](agents/system-diagnostics.md) |
| `src/system/registry-snapshot.ts` | Sanitized plain-JSON projection of the booted `ObjectRegistry` for the smrt-dev-mcp runtime dev-plane (#1831); never constructors, validators, values, or absolute paths | [agents/registry-snapshot.md](agents/registry-snapshot.md) |
| `src/registry/qualified-name-aliases.ts`, `src/migrations/qualified-name-aliases.ts` | Model moves: `previousQualifiedNames` aliases, deprecation, doctor counts, opt-in backfill (#3338) | [agents/model-moves.md](agents/model-moves.md) |
| `src/run-once.ts` | Shared idempotency seam: insert-only claim + caller work in one transaction, replay on retry, typed in-flight/unknown-outcome answers (#3080) | [agents/run-once.md](agents/run-once.md) |
| `src/recipe.ts`, `../scanner/src/recipes.ts` | `SmrtRecipe`: declared user-facing units (models, nav, `requires`, curation `options`) collected into manifest and knowledge `recipes` (#3590) | [agents/recipes.md](agents/recipes.md) |
| `src/browser.ts`, `src/host.ts`, `src/host.browser.ts` | Browser entry that builds and evaluates without Node-only modules: host seam, `package.json#browser` swaps, `pnpm test:browser` (#2838) | [agents/browser-entry.md](agents/browser-entry.md) |

## Cross-module invariants

- `ObjectRegistry` is a `globalThis` singleton so registration survives HMR.
- Any output that names a database URL (CLI banners, logs, errors) renders it
  with `redactDatabaseUrl` / `redactDatabaseUrlsInText`
  (`src/utils/database-url.ts`, #3527): never the password or query string,
  and never the raw string when it cannot be parsed.
- Per-class registry work on the hydration path (manifest reconciliation in
  `ensureManifestLoaded()`, the simple-name index behind `findClass()`) is
  memoized per registry generation (`src/registry/generation.ts`, #3047). Any
  new writer of registered classes, their field/method metadata, or loaded
  manifests must go through the tracked maps or call
  `bumpRegistryGeneration()`; `issue-3047-hydration-registry-work.test.ts`
  guards that hydration does not repeat this work per row.

- Production DDL uses manifest generators; `getTestDatabase()` uses registry
  generators. Keep columns, indexes, FK actions, and runtime conflict targets in
  parity (`src/schema/schema-path-parity.test.ts`). Every new query predicate
  needs its index or an explicit reason none is needed.
- Tenant scoping covers every read and every unique/conflict key. Explicit
  conflict columns are not rewritten; their author must include tenant scope.
  A `tenantId` field makes rows tenant-OWNED without any tenancy declaration:
  the default key leads with `tenant_id`. A new object's natural-key save reads
  the row its upsert would hit and refuses a different owner
  (`TENANT_ISOLATION_VIOLATION`) or adopts a same-owner row's id, so
  `DO UPDATE` never rewrites a primary key or owner. Only an explicit natural
  key adopts: a slug `getSlug()` derived from `name`/`title`/`label` moves to
  a free `-2`, `-3`, … slug and INSERTs. See `agents/schema-paths.md`
  ("Tenant OWNERSHIP").
- Persisted saves use `id` and loaded `updated_at`; new saves use natural keys.
  Preserve revision compare-and-swap ordering through public `save()`,
  `claimRevision()`, and transaction APIs. Embedded saves, deletes, and complete
  `withTransaction()` callbacks share a process-local write queue.
- Collection model hydration is serial in result order: initialization may query
  the same transaction-bound PostgreSQL client. Use projections for plain rows.
- Native DuckDB UUIDs must be cast coherently on read before identity reuse;
  custom embedded revision paths use `getCanonicalPersistedRow()`. Never replay
  a mutation to discover result types.
- `withDatabase(db, callback)` restores only database bindings (including public
  `options.db`); `withTransaction(callback)` also restores identity/revision
  metadata after rollback. Do not use a bound instance concurrently.
- `runOnce({ db, tenantId, actor, token, content }, work)` (`src/run-once.ts`,
  #3080) claims a key derived from all four inputs — never the token alone,
  which collapses distinct submissions — via `INSERT ... ON CONFLICT
  (claim_key) DO NOTHING RETURNING claim_key` into the hand-DDL
  `_smrt_run_once_claims` system table, and runs `work` in the SAME
  transaction; a completed claim replays its stored result instead of
  re-running, a failed `work` rolls the claim back with the transaction, and
  an unresolved claim raises typed `RunOnceClaimError`
  (`RUN_ONCE_IN_FLIGHT` / `RUN_ONCE_OUTCOME_UNKNOWN`) rather than guessing.
  The claim insert must never raise on conflict: PostgreSQL aborts the whole
  transaction on any raised error, which would take the recovery `SELECT`
  down with it too — this is why it is `DO NOTHING`, not a plain `INSERT`
  caught for `isUniqueViolationError`. Completed claims are bounded by
  `runRetentionSweep()`'s `run-once-claims` task (`system/retention.ts`,
  `DEFAULT_RETENTION_POLICY.runOnceClaims`, default 30 days on
  `completed_at`; `in_progress` rows are never matched) — the window is a
  replay deadline, not just disk hygiene: a token replayed after its claim
  is swept runs `work()` again. See `agents/run-once.md`.
- `ensureSystemTables(db, typeHint?)` provisions framework tables idempotently;
  call it on a base PostgreSQL connection before caller-owned transactions.
  Bootstrap uses a transaction-scoped advisory lock, taken only when the
  PostgreSQL schema version is not yet stamped: inside a caller's transaction it
  is held until that transaction ends (#2868). Application tables still require migrations;
  runtime table verification checks existence only.
- Manifest generation fails closed on scanner errors, including unresolved
  decorator spreads. Never emit partial, default-open registration.
- Generated registration repairs bundled class identity using the exact imported
  constructor, explicit package, and isolated one-object manifest. Never infer
  ownership from paths, simple names, or table names; packages can share names.
  Consumer regression gate: `packages/bundle-gate/src/__tests__/registry-identity.spec.ts`.
- Decorator registration trusts a class's stack-derived package only when that
  package declares the class (stub, own manifest entry, or explicit
  `packageName`); it then matches the qualified key and never adopts another
  package's same-named registration. Otherwise a loaded (or the cwd project's)
  manifest entry describing the declaring file supplies the identity — apps
  scan workspace-package sources under the app's name (#3110). A class of
  another known package coexists under its qualified key
  (`decorator-different-packages-qualified-coexist`); bundled output needs
  a resolved table that differs first (#3106). Stack
  attribution skips smrt-core (including source-mapped installed
  `smrt-core/src` frames, #3109), decorator-helper, and module-runner frames,
  and drops a frame's Vite `?v=` query (#3490). Library builds stamp each
  decorated class with `static __smrtPackage__` (own property, read at
  decoration as its explicit package) and publish `stampsConstructors`; an
  unstamped class never takes a stamping package's entry by name and table,
  in either order (#3490, `issue-3490-*.test.ts`, `package-stamp.test.ts`).
  Qualified names are `@scope/pkg:Class`; the scope is a deliberate
  discriminator, so manifest generation (`generateManifest`,
  `applyGenerationPasses`, hence `pnpm build`) throws
  `CONFIG_UNSCOPED_PACKAGE_NAME` for an unscoped `package.json` name (#3408).
  Instance and collection registry lookups pass the qualified name. The schema
  planner rejects a table claimed by two unrelated classes
  (`CONFIG_TABLE_NAME_COLLISION`): only one STI family shares a table (#3098);
  collections (including `SmrtReportCollection`) never claim one. Consumer
  gates: `registry/__tests__/issue-3110-*.test.ts`, `issue-3109-*.test.ts`,
  `packages/bundle-gate/src/__tests__/consumer-same-name.spec.ts`.
- API custom-action eligibility has ONE resolver, `resolveApiMethodExposure()`
  in `generators/custom-action.ts`: both SvelteKit route emitters,
  `resolveApiActionSet`, and `knowledge.ts` read it, and a new consumer must too
  — a local mirror is how a method gets reported unavailable while its route
  file is still written. A public method routes by default only when every
  parameter is JSON-shaped; `@method({ expose })` overrides in both directions,
  `expose: true` bypasses the heuristic ALONE, and an explicit `api.include` or
  `api.routes` entry keeps its pre-#2686 route. Fail closed on scanner
  uncertainty: read `parameters[].typeUnresolved`, never the `'any'` it
  substitutes. Accepting `Date` as wire-able and hydrating it
  (`toCustomActionDate`) are one decision — changing either breaks the other.
  The runtime `APIGenerator` transport stays declaration-gated: `rest.ts`
  dispatch and `preflight-route.ts` prediction both read
  `declaresRuntimeRestRoute()`, which must accept every `ApiCustomRouteConfig`
  option so a sweep moving one onto its method cannot delete the endpoint. Its
  twin `declaresRuntimeRestRouteShape()` deliberately ignores `expose: false`:
  the dispatcher must still SEE a withheld declaration to answer 404, because
  `POST /<collection>/<segment>` resolves to `create` when nothing claims the
  segment. Split unions and type arguments with `splitTopLevel()` — a naive
  `split('|')` truncates `Record<string, Asset | null>` into fragments that
  match no rule and are then accepted, widening the gate. `extractTypeName`
  returns `null` for a generic with an unresolvable ARGUMENT or a union with an
  unresolvable BRANCH so those reach that fail-closed path instead of arriving
  as a bare `'Array'`. Runtime transports read
  `ObjectRegistry.resolveRuntimeMethod()`, which tries the item class's manifest
  entry, then the COLLECTION class's (where a collection-hosted action's
  parameters live), then the live `@method()` store — keyed by CONSTRUCTOR,
  never by simple name (`Account` exists in two packages), and recording
  `isStatic` because an unscanned runtime has no manifest to recover the
  receiver from. `isRestActionRoutable` ANDs "declared" with that receiver, so
  it never predicts `allow` for an action dispatch refuses. A declared action
  with no receiver is refused (501 collection-scoped, 404 item-scoped), never
  allowed to fall through into `create`. All eight consumers read the resolver,
  including `packages/smrt-workbench/src/discovery.ts`; it imports the
  `./generators/custom-action` LEAF subpath, not `./generators`, because that
  barrel value-re-exports `MCPGenerator` and so drags `@happyvertical/ai` and
  `@happyvertical/sql` into a build-time helper (2 modules vs 109). Keep
  `custom-action.ts` free of value imports outside `tools/tool-generator`.

## Gotchas

- Optional filesystem support stays lazy: use `createFilesystemAdapter()` in
  `src/filesystem-loader.ts`, not a static files-SDK import. Fully bundled apps
  import `@happyvertical/smrt-core/filesystem` at startup. Use
  `importOptionalDependency()` for similarly heavy optional dependencies.
- `src/browser.ts` is the `browser`-condition entry of the package root: the
  Node entry (`index.ts`) minus HTTP servers, manifest/knowledge discovery, run-once,
  the Vite plugin, and the test helper. A new export added to `index.ts` must also
  go to `browser.ts` unless it is Node-only; `src/__tests__/browser-entry-parity.test.ts`
  fails otherwise (allowlist: `NODE_ONLY_GROUPS` in that test, each with a reason; the browser
  entry may not publish a name the Node entry lacks), and also
  fails when a workspace package imports a root value the browser entry lacks.
- `exports['.'].browser` (`dist/browser.js`) is the browser surface. Model
  package roots are bundled for browsers by the bundle-gate browser fixture
  (#3621): anything a model root imports from core must be exported by the
  browser entry and must not reach `node:` built-ins, `pg`, `cosmiconfig`, or
  `jiti`. Keep Node-only code behind a subpath or a lazy import; when a fix
  makes a package pass, delete its entry in
  `packages/bundle-gate/src/browser-gate/expected-failures.ts`.
- Database retries are transient-only, four attempts total for `get`/`upsert`.
  Use `src/db-errors.ts` classifiers through the cause chain, never message
  matching (SDK driver text can live in `context.originalError`). Constraints,
  bad input, missing tables, and aborted PostgreSQL transactions fail immediately.
  Unique/PK violations become `VALIDATION_UNIQUE_CONSTRAINT`, NOT NULL becomes
  `VALIDATION_REQUIRED_FIELD`; other failures keep the driver error as `cause`.
- Property initializers precede option values; options win. Arrays/objects are
  shallow-cloned. Collection creation caches fields; table verification caches
  by DB URL and table. Preserve these scopes when changing initialization.
- The Vite plugin loads scanner/schema code from `dist/` when present. Rebuild
  core after editing those sources before testing consumer manifest generation.
  Vite 8 requires `oxc.decorator: { legacy: true, emitDecoratorMetadata: true }`.

## Validation

`typecheck` checks production source first, then the test project in
`tsconfig.test.json`. Test coverage and the shared relaxed config
contract are documented in [agents/test-types.md](agents/test-types.md).

Run focused tests first, then applicable package checks:

```bash
pnpm --filter @happyvertical/smrt-core test
pnpm --filter @happyvertical/smrt-core typecheck
pnpm --filter @happyvertical/smrt-core build
pnpm --filter @happyvertical/smrt-core test:postgres
pnpm check:agents-chain
pnpm smrt dev:knowledge-check
```

The PostgreSQL lane is required for numeric types, UUID casts, conflict targets,
timestamps, and migrations. Tests generate their manifest before Vitest; restart
watch mode after adding decorated classes. Documentation-only changes need
instruction-chain and knowledge freshness checks, not the runtime test suite.
