# @happyvertical/ai

<!-- BEGIN AGENT:GENERATED -->
## Purpose
Standardized AI interface supporting chat, embeddings, media, and TypeSafe/Jev typed decisions

## Package Map
- Package: `@happyvertical/ai`
- Hierarchy path: `@happyvertical/sdk > packages > ai`
- Workspace position: `2 of 33` local packages
- Internal dependencies: `@happyvertical/utils`
- Internal dependents: `@happyvertical/sdk-mcp`
- Knowledge graph files: `AGENT.md`, `metadata.json`, `ecosystem-manifest.json`

## Build & Test
```bash
pnpm --filter @happyvertical/ai build
pnpm --filter @happyvertical/ai test
pnpm --filter @happyvertical/ai clean
```

## Agent Correction Loops
- If module resolution or export errors mention a workspace dependency, build the dependency first (`pnpm --filter @happyvertical/utils build`) and then rerun `pnpm --filter @happyvertical/ai build`.
- If tests or exports fail after API, type, or bundle changes, run `pnpm --filter @happyvertical/ai clean` followed by `pnpm --filter @happyvertical/ai build` and `pnpm --filter @happyvertical/ai test`.
- If failures span multiple packages or Turborepo ordering looks wrong, run `pnpm build` and `pnpm typecheck` from the repo root before retrying package-scoped commands.

## Ecosystem Relationships
- Provides: Standardized AI interface supporting chat, embeddings, media, and TypeSafe/Jev typed decisions
- Implements: none
- Requires: @happyvertical/utils, @anthropic-ai/sdk, @aws-sdk/client-bedrock-runtime, @google/genai, @mlc-ai/web-llm, openai
- Stability: stable (Primary package surface is described as implemented and production-oriented.)
<!-- END AGENT:GENERATED -->
